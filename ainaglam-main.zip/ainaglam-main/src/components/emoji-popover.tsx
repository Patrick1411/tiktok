import { useState } from "react";
import data from "@emoji-mart/data";
import Picker from "@emoji-mart/react";

import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./ui/tooltip";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";

interface EmojiPopoverProps {
  children: React.ReactNode;
  hint?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onEmojiSelect: (emoji: any) => void;
}

export const EmojiPopover = ({
  children,
  hint = "絵文字",
  onEmojiSelect,
}: EmojiPopoverProps) => {
  const [popoverOpen, setPopoverOpen] = useState(false);
  const [tootltipOpen, setTootltipOpen] = useState(false);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const onSelect = (emoji: any) => {
    onEmojiSelect(emoji);
    setPopoverOpen(false);

    setTimeout(() => {
      setTootltipOpen(false);
    }, 500);
  };

  return (
    <TooltipProvider>
      <Popover
        open={popoverOpen}
        onOpenChange={setPopoverOpen}
      >
        <Tooltip
          open={tootltipOpen}
          onOpenChange={setTootltipOpen}
          delayDuration={50}
        >
          <PopoverTrigger asChild>
            <TooltipTrigger asChild>
              {children}
            </TooltipTrigger>
          </PopoverTrigger>
          <TooltipContent
            className="
              bg-black 
              text-white 
              border 
              border-white/5
            "
          >
            <p className="font-medium text-xs">{hint}</p>
          </TooltipContent>
        </Tooltip>
        <PopoverContent
          className="
            p-0 
            w-full 
            border-none 
            shadow-none            
          "
        >
          <Picker data={data} onEmojiSelect={onSelect} />
        </PopoverContent>
      </Popover> 
    </TooltipProvider>
  );
};

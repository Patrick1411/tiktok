import Quill from "quill";
import { useEffect, useRef, useState } from "react";
import { useGetOgp } from "@/features/messages/api/use-get-ogp";

interface RendererProps {
  value: string;
}

const makeALink = (text: string) => {
  const urlPattern = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%=~_|!:,.; ]*[-A-Z0-9+&@#\/%=~_|])/gi;
  return text.replace(urlPattern, (url) => {
    return `<a href='${url}' target='_blank' rel="noopener noreferrer" className="flex items-start gap-4 p-4 hover:bg-gray-50 transition">${url}</a>`;
  });
};

const extractFirstUrl = (text: string): string | undefined => {
  const urlRegex = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%=~_|!:,.; ]*[-A-Z0-9+&@#\/%=~_|])/gi;
  const urls = text.match(urlRegex);
  return urls?.[0];
};

const Renderer: React.FC<RendererProps> = ({ value }) => {
  const [isEmpty, setIsEmpty] = useState(false);
  const [firstUrl, setFirstUrl] = useState<string | undefined>(undefined);
  const rendererRef = useRef<HTMLDivElement>(null);
  const { data, isLoading } = useGetOgp(firstUrl);

  useEffect(() => {
    if (!rendererRef.current) return;

    const container = rendererRef.current;

    try {
      const quill = new Quill(document.createElement("div"), {
        theme: "snow",
      });

      quill.enable(false);

      const contents = JSON.parse(value);
      quill.setContents(contents);

      const isEmpty = quill.getText().trim().length === 0;
      setIsEmpty(isEmpty);

      const encodedSentence = makeALink(quill.root.innerHTML);
      const extractedUrl = extractFirstUrl(quill.root.innerHTML);
      if (extractedUrl){
        setFirstUrl(extractedUrl);
        if (!isLoading && data) {
          const ogpHtml = `<div class="overflow-hidden border rounded-md shadow-sm px-3 py-3"><p class="font-bold text-[18px]">${data.siteName === null ? '' :data.siteName}</p><div class="flex-1  space-y-1 overflow-hidden"><h3 class="font-semibold text-base text-[#1264A3] line-clamp-2">${data.title ? data.title : ''}</h3>${data.description ? `<p class="text-sm text-gray-600 line-clamp-2">${data.description}</p>` : ''}</div>${data.image ? `<div class="h-24 w-24 flex-shrink-0"><img src="${data.image}" alt="${data.title ? data.title : ''}" class="entity-image inset-0 w-full h-full object-cover rounded-md" /></div>` : ``}</div>`;
          
          if(data.siteName === null
            && data.title === null
            && data.description === null
            && data.image === null
          ){
            container.innerHTML = encodedSentence
          }else {
            container.innerHTML = encodedSentence + ogpHtml
          }        
        }
      }else{
        container.innerHTML = encodedSentence
      }
      
      

    } catch (error) {
      console.error("コンテンツのレンダリングエラー:", error);
      container.innerHTML = "コンテンツのレンダリングエラー";
    }

    return () => {
      container.innerHTML = "";
    };
  }, [value, data, isLoading]);

  if (isEmpty) return null;

  return <div ref={rendererRef} className="ql-editor ql-renderer" />;
};

export default Renderer;


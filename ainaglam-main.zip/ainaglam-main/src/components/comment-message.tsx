"use client";

import { ChatInput } from "@/app/workspace/[workspaceId]/comments/chat-input";
import { Message } from "./message";
import { GetCommentReturnType } from "@/features/messages/api/use-get-comments";
import { useState } from "react";
import { Id } from "../../convex/_generated/dataModel";
import { userCurrentUser } from "@/features/auth/api/user-current-user";

interface CommentMessageProps {
  comment: GetCommentReturnType | undefined;
}

const CommentMessage = ({ comment }: CommentMessageProps) => {
  const [editingId, setEditingId] = useState<Id<"messages"> | null>(null);
  const { data, isLoading } = userCurrentUser();
  if (!comment) return null;
  const { parent, children } = comment;
  if (isLoading) return;  

  const otherUser = children.find(child => {
    if (child?.user._id !== data?.user._id) {
      return child?.user.name;
    }
  })

  return (
    <div className="w-full h-full p-5 space-y-4">
      <div
        className="
          text-black
          font-semibold
          pl-3
          flex
          items-center
        "
      >
        {parent?.channel?.name
          ? `# ${parent?.channel?.name}`
          : parent?.user._id !== data?.user._id
            ? `${parent?.user.name ? parent?.user.name:''} とあなた`
            : otherUser ? `あなたと${otherUser}` : 'あなた'
        }
      </div>
      <div className="bg-white rounded-lg p-4">
        {parent &&
          (
            <div className="bg-white">              
              <Message
                key={parent._id}
                id={parent._id}
                memberId={parent.memberId}
                authorImage={parent.user.image || undefined}
                authorName={parent.user.displayName || parent.user.name}
                isAuthor={parent.user._id === data?.user._id}
                reactions={parent.reactions}
                body={parent.body ?? ''}
                image={parent.image}
                audio={parent.audio}
                video={parent.video}
                updatedAt={parent.updatedAt}
                createdAt={parent._creationTime}
                isEditing={editingId === parent._id}
                setEditingId={setEditingId}
                hideThreadButton
              />
            </div>
          )
        }
        {children && children.length > 0 && (
          <div className="">
            {children.map((childMessage) => (
              childMessage && (
                <div key={childMessage._id} className="">
                  <Message
                    key={childMessage._id}
                    id={childMessage._id}
                    memberId={childMessage.memberId}
                    authorImage={childMessage.user.image || undefined}
                    authorName={childMessage.user.displayName || childMessage.user.name}
                    isAuthor={childMessage.user._id === data?.user._id}
                    reactions={childMessage.reactions}
                    body={childMessage.body ?? ''}
                    image={childMessage.image}
                    audio={childMessage.audio}
                    video={childMessage.video}
                    updatedAt={childMessage.updatedAt}
                    createdAt={childMessage._creationTime}
                    isEditing={editingId === childMessage._id}
                    setEditingId={setEditingId}
                    hideThreadButton
                  />
                </div>
              )
            ))}
          </div>
        )}
        <ChatInput
          parentMessageId={parent?._id}
          conversationId={parent?.conversationId}
          channelId={parent?.channelId}
          placeholder={`Message # ${parent?.channel?.name || ""}`} />
      </div>
    </div>
  );
}

export default CommentMessage;


"use client";

import { ScrollArea } from "@/components/ui/scroll-area";
import CommentMessage from "./comment-message";
import { GetCommentsReturnType } from "@/features/messages/api/use-get-comments";

interface CommentMessageListProps {
  comments: GetCommentsReturnType | undefined;
}

export const CommentMessageList = ({ comments }: CommentMessageListProps) => {
  if (!comments) return null;

  return (
    <ScrollArea className="w-full h-full bg-gray-100 p-4">
      {Object.entries(comments).map(([parentId, threadData]) => (
        <div key={parentId} className="mb-6">
          {threadData && (
            <CommentMessage comment={threadData} />
          )}
        </div>
      ))}
    </ScrollArea>
  );
};

import Image from "next/image";
import { Delta, Op } from "quill/core";
import { MdSend } from "react-icons/md";
import { PiTextAa } from "react-icons/pi";
import { ImageIcon, Smile, XIcon, Mic, Video } from 'lucide-react';
import Quill, { type QuillOptions } from "quill";
import {
  MutableRefObject,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
} from "react";

import "quill/dist/quill.snow.css";

import { cn } from "@/lib/utils";

import { Hint } from "./hint";
import { Button } from "./ui/button";

import { EmojiPopover } from "./emoji-popover";

type EditorValue = {
  image: File | null;
  audio: File | null;
  video: File | null;
  body: string;
};

interface EditorProps {
  onSubmit: ({ image, audio, video, body }: EditorValue) => void;
  onCancel?: () => void;
  placeholder?: string;
  defaultValue?: Delta | Op[];
  disabled?: boolean;
  innerRef?: MutableRefObject<Quill | null>;
  variant?: "create" | "update";
}

const Editor = ({
  onSubmit,
  onCancel,
  placeholder = "何か書いてください...",
  defaultValue = [],
  disabled = false,
  innerRef,
  variant = "create",
}: EditorProps) => {
  const [text, setText] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [audio, setAudio] = useState<File | null>(null);
  const [video, setVideo] = useState<File | null>(null);
  const [isToolbarVisible, setIsToolbarVisible] = useState(true);

  const submitRef = useRef(onSubmit);
  const placeholderRef = useRef(placeholder);
  const quillRef = useRef<Quill | null>(null);
  const defaultValueRef = useRef(defaultValue);
  const containerRef = useRef<HTMLDivElement>(null);
  const disabledRef = useRef(disabled);
  const imageElementRef = useRef<HTMLInputElement>(null);
  const audioElementRef = useRef<HTMLInputElement>(null);
  const videoElementRef = useRef<HTMLInputElement>(null);

  useLayoutEffect(() => {
    submitRef.current = onSubmit;
    placeholderRef.current = placeholder;
    defaultValueRef.current = defaultValue;
    disabledRef.current = disabled;
  });

  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    const editorContainer = container.appendChild(
      container.ownerDocument.createElement("div")
    );

    const options: QuillOptions = {
      theme: "snow",
      placeholder: placeholderRef.current,
      modules: {
        toolbar: [
          ["bold", "italic", "underline", "strike"],
          [{ list: "ordered" }, { list: "bullet" }],
          [{ script: "sub" }, { script: "super" }],
          ["link"],
        ],
        keyboard: {
          bindings: {
            enter: {
              key: "Enter",
              handler: () => {
                const text = quill.getText();
                const addedImage = imageElementRef.current?.files?.[0] || null;
                const addedAudio = audioElementRef.current?.files?.[0] || null;
                const addedVideo = videoElementRef.current?.files?.[0] || null;

                const isEmpty =
                  !image &&
                  !audio &&
                  !video &&
                  text.replace(/<(.|\n)*?>/g, "").trim().length === 0;

                if (isEmpty) return;

                const body = JSON.stringify(quill.getContents());
                submitRef.current?.({
                  body,
                  image: addedImage,
                  audio: addedAudio,
                  video: addedVideo
                });
              },
            },
            shift_enter: {
              key: "Enter",
              shiftKey: true,
              handler: () => {
                quill.insertText(quill.getSelection()?.index || 0, "\n");
              },
            },
          },
        },
      },
    };

    const quill = new Quill(editorContainer, options);
    quillRef.current = quill;
    quillRef.current.focus();

    if (innerRef) {
      innerRef.current = quill;
    }

    quill.setContents(defaultValueRef.current);
    setText(quill.getText());

    quill.on(Quill.events.TEXT_CHANGE, () => {
      setText(quill.getText());
    });

    return () => {
      quill.off(Quill.events.TEXT_CHANGE);

      if (container) {
        container.innerHTML = "";
      }
      if (quillRef.current) {
        quillRef.current = null;
      }
      if (innerRef) {
        innerRef.current = null;
      }
    };
  }, [audio, image, innerRef, video]);

  const toogleToolbar = () => {
    setIsToolbarVisible((current) => !current);
    const toolbarElement = containerRef.current?.querySelector(".ql-toolbar");

    if (toolbarElement) {
      toolbarElement.classList.toggle("hidden");
    }
  };

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const onEmojiSelect = (emoji: any) => {
    const quill = quillRef.current;

    quill?.insertText(quill?.getSelection()?.index || 0, emoji.native);
  };

  const isEmpty = !image && !audio && !video && text.replace(/<(.|\n)*?>/g, "").trim().length === 0;

  return (
    <div className="flex flex-col">
      <input
        type="file"
        accept="image/*"
        ref={imageElementRef}
        onChange={(e) => setImage(e.target.files![0])}
        className="hidden"
      />
      <input
        type="file"
        accept="audio/*"
        ref={audioElementRef}
        onChange={(e) => setAudio(e.target.files![0])}
        className="hidden"
      />
      <input
        type="file"
        accept="video/*"
        ref={videoElementRef}
        onChange={(e) => setVideo(e.target.files![0])}
        className="hidden"
      />
      <div
        className={cn(
          "flex flex-col border border-slate-200 rounded-md overflow-hidden focus-within:border-slate-300 focus-within:shadow-sm transition bg-white",
          disabled && "opacity-50"
        )}
      >
        <div ref={containerRef} className="h-full ql-custom" />
        {(!!image || !!audio || !!video) && (
          <div className="p-2 flex gap-2">
            {!!image && (
              <div className="relative size-[62px] flex items-center justify-center group/image">
                <Hint label="画像を削除">
                  <button
                    onClick={() => {
                      setImage(null);
                      imageElementRef.current!.value = "";
                    }}
                    className="hidden group-hover/image:flex rounded-full bg-destructive hover:bg-destructive text-secondary absolute -top-2 -right-2 size-5 z-[4] items-center justify-center"
                  >
                    <XIcon className="size-3.5" />
                  </button>
                </Hint>
                <Image
                  src={URL.createObjectURL(image)}
                  alt="アップロード済み"
                  fill
                  className="rounded-xl overflow-hidden border object-cover"
                />
              </div>
            )}
            {!!audio && (
              <div className="relative size-[62px] flex items-center justify-center group/audio">
                <Hint label="音声を削除">
                  <button
                    onClick={() => {
                      setAudio(null);
                      audioElementRef.current!.value = "";
                    }}
                    className="hidden group-hover/audio:flex rounded-full bg-destructive hover:bg-destructive text-secondary absolute -top-2 -right-2 size-5 z-[4] items-center justify-center"
                  >
                    <XIcon className="size-3.5" />
                  </button>
                </Hint>
                <Mic className="size-8 text-slate-500" />
              </div>
            )}
            {!!video && (
              <div className="relative size-[62px] flex items-center justify-center group/video">
                <Hint label="動画を削除">
                  <button
                    onClick={() => {
                      setVideo(null);
                      videoElementRef.current!.value = "";
                    }}
                    className="hidden group-hover/video:flex rounded-full bg-destructive hover:bg-destructive text-secondary absolute -top-2 -right-2 size-5 z-[4] items-center justify-center"
                  >
                    <XIcon className="size-3.5" />
                  </button>
                </Hint>
                <Video className="size-8 text-slate-500" />
              </div>
            )}
          </div>
        )}
        <div className="flex px-2 pb-2 z-[5]">
          <Hint label={isToolbarVisible ? "書式を非表示" : "書式を表示"}>
            <Button
              disabled={disabled}
              variant="ghost"
              size="icon"
              onClick={toogleToolbar}
            >
              <PiTextAa className="size-4" />
            </Button>
          </Hint>
          <EmojiPopover onEmojiSelect={onEmojiSelect}>
            <Button disabled={disabled} size="icon" variant="ghost">
              <Smile className="size-4" />
            </Button>
          </EmojiPopover>
          {variant === "create" && (
            <>
              <Hint label="画像">
                <Button
                  disabled={disabled}
                  variant="ghost"
                  size="icon"
                  onClick={() => imageElementRef.current?.click()}
                >
                  <ImageIcon className="size-4" />
                </Button>
              </Hint>
              <Hint label="音声">
                <Button
                  disabled={disabled}
                  variant="ghost"
                  size="icon"
                  onClick={() => audioElementRef.current?.click()}
                >
                  <Mic className="size-4" />
                </Button>
              </Hint>
              <Hint label="動画">
                <Button
                  disabled={disabled}
                  variant="ghost"
                  size="icon"
                  onClick={() => videoElementRef.current?.click()}
                >
                  <Video className="size-4" />
                </Button>
              </Hint>
            </>
          )}
          {variant === "update" && (
            <div className="ml-auto flex items-center gap-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={onCancel}
                disabled={disabled}
              >
                閉じる
              </Button>
              <Button
                disabled={disabled || isEmpty}
                onClick={() => {
                  onSubmit({
                    body: JSON.stringify(quillRef.current?.getContents()),
                    image,
                    audio,
                    video,
                  });
                }}
                size="sm"
                className="bg-[#007A5A] hover:bg-[#007A5A]/80 text-white"
              >
                保存
              </Button>
            </div>
          )}
          {variant === "create" && (
            <Button
              disabled={disabled || isEmpty}
              onClick={() => {
                onSubmit({
                  body: JSON.stringify(quillRef.current?.getContents()),
                  image,
                  audio,
                  video,
                });
              }}
              size="iconSm"
              className={cn(
                "ml-auto",
                isEmpty
                  ? "bg-white text-muted-foreground hover:bg-white"
                  : "bg-[#007A5A] text-white hover:bg-[#007A5A]/80"
              )}
            >
              <MdSend className="size-4" />
            </Button>
          )}
        </div>
      </div>
      {variant === "create" && (
        <div
          className={cn(
            "p-2 text-[10px] text-muted-foreground flex justify-end opacity-0 transition",
            !isEmpty && "opacity-100"
          )}
        >
          <p>
            <strong>Shift + Enter</strong> で新しい行を追加します
          </p>
        </div>
      )}
    </div>
  );
};

export default Editor;
import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { userCurrentUser } from "@/features/auth/api/user-current-user";
import { Button } from "./ui/button";
import { ProfileEditModal } from "@/app/workspace/[workspaceId]/profile-edit-modal";

interface ConversationHeroProps {
  name?: string;
  displayName?: string;
  image?: string;
  id?: string;
}

export const ConversationHero = ({
  name = "会員",
  displayName = "会員",
  image,
  id
}: ConversationHeroProps) => {
  const avatarFallback = displayName.charAt(0).toUpperCase();
  const initialValues = {
    fullName: name,
    displayName: displayName,
    photoUrl: image
  };

  const { data: currentUser, isLoading } = userCurrentUser();
  const isOwnProfile = currentUser?.user._id === id;

  const [open, setOpen] = useState(false);

  return (
    <>
      <ProfileEditModal
        open={open}
        setOpen={setOpen}
        initialValues={initialValues}
      />
      <div className="mt-[88px] mx-5 mb-4">
        <div className="flex items-center gap-x-1 mb-2">
          <Avatar
            className="
            size-14 
            rounded-md 
            transition 
            mr-2
          "
          >
            <AvatarImage
              src={image}
              className="
              rounded-md
            "
            />
            <AvatarFallback
              className="
              rounded-md
              bg-sky-500 
              text-white
            "
            >
              {avatarFallback}
            </AvatarFallback>
          </Avatar>
          <p className="text-2xl font-bold">{displayName}</p>
        </div>
        <p className="font-normal text-slate-800 mb-4">
          この会話はあなたと <strong>{name}</strong> の間だけのものです
        </p>
        {isOwnProfile && !isLoading && (
          <Button
            variant="outline"
            onClick={() => setOpen(true)}
          >
            プロフィールを編集
          </Button>
        )}
      </div>
    </>
  );
};

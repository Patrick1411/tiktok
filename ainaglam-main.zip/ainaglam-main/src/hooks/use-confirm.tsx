import { useState } from "react";

import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter
} from "@/components/ui/dialog"
import { DialogDescription } from "@radix-ui/react-dialog";
import { Button } from "@/components/ui/button";

export const useConfirm = (
    title: string,
    message: string,
    btnName?: string
): [() => JSX.Element, () => Promise<unknown>] => {
    const [promise, setPromise] = useState<{ resolve: (value: boolean) => void } | null>(null);

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const confirm = () => new Promise((resolve, reject) => {
        setPromise({ resolve });
    });

    const handleClose = () => {
        setPromise(null);
    }

    const handleCancel = () => {
        promise?.resolve(false);
        handleClose();
    }

    const handleConfirm = () => {
        promise?.resolve(true);
        handleClose();
    }

    const ConfirmDialog = () => {
        return (
            <Dialog open={promise !== null}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>
                            {title}
                        </DialogTitle>
                        <DialogDescription>
                            {message}
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter className="pt-2">
                        <Button
                            onClick={handleCancel}
                            variant="outline"
                        >
                            閉じる
                        </Button>
                        <Button
                            onClick={handleConfirm}
                        >
                            {!!btnName ? btnName : `保存`}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        );

    }

    return [ConfirmDialog, confirm];
}
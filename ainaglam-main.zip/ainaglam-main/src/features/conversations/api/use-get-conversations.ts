import { useQuery } from "convex/react";
import { api } from '../../../../convex/_generated/api';
import { Id } from "../../../../convex/_generated/dataModel";

interface UseGetConversationsProps {
    workspaceId: Id<'workspaces'>;
}

export type GetConversationReturnType = typeof api.conversations.getConversations._returnType;

export const useGetConversations = ({ workspaceId }: UseGetConversationsProps) => {
    const result = useQuery(
        api.conversations.getConversations, { workspaceId }
    );

    return {
        isLoading: false,
        conversations: result?.existingConversations,
        currentMemberId: result?.currentMemberId
    };
};


"use client";

import { useQuery } from "convex/react"

import { api } from "../../../../convex/_generated/api"


export type GetCommentsReturnType = typeof api.messages.getComments._returnType;
export type GetCommentReturnType = typeof api.messages.getComments._returnType["page"];
export const useGetComments = () => {
  const data = useQuery(api.messages.getComments);
  const isLoading = data === undefined

  return { data, isLoading }
}

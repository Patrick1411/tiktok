import { useQuery } from "convex/react";
import { api } from '../../../../convex/_generated/api';
import { Id } from "../../../../convex/_generated/dataModel";

interface UseGetUnreadsProps {
    workspaceId: Id<'workspaces'>;
}

export type GetUnreadsReturnType = typeof api.unread.getUnreadMessages._returnType;

export const useGetUnreads = ({ workspaceId }: UseGetUnreadsProps) => {
    const result = useQuery(
        api.unread.getUnreadMessages, { workspaceId }
    );

    if (result === undefined) {
        return { isLoading: true, unreadCounts: [], totalUnreadCount: 0 };
    }

    if (result === null) {
        return { isLoading: false, unreadCounts: [], totalUnreadCount: 0 };
    }

    return {
        isLoading: false,
        unreadCounts: result.unreadCounts,
        totalUnreadCount: result.totalUnreadCount,
    };
};


import { useState, useEffect } from 'react';
import { useAction } from 'convex/react';
import { OgpData } from '../../../../convex/ogp';
import { api } from '../../../../convex/_generated/api';

export function useGetOgp(url: string | undefined) {
    const [data, setData] = useState<OgpData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    const fetchOgpData = useAction(api.ogp.fetchOgpData);


    useEffect(() => {
        async function fetchData() {
            if (url) {
                setIsLoading(true);

                try {
                    if (url.includes("silent-marten-798") || url.includes("limitless-meadowlark-865")) {
                        setData(null);
                    } else {
                        const fetchedData = await fetchOgpData({ url });
                        if (fetchedData) {
                            setData(fetchedData);
                        }
                    }
                } catch (error) {
                    console.error('Error fetching OGP data:', error);
                }
            }
            setIsLoading(false);
        }


        fetchData();
    }, [url, fetchOgpData,]);

    return { data, isLoading };
}


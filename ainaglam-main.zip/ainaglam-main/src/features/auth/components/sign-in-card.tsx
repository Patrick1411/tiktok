import { useState } from "react";
import { FaGithub } from "react-icons/fa";
import { FcGoogle } from "react-icons/fc";
import { TriangleAlert } from "lucide-react";
import { useAuthActions } from "@convex-dev/auth/react";
import { Button } from "@/components/ui/button";
import {
    Card,
    CardContent,
    CardHeader
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import Image from 'next/image'

import logoMark from "@/../public/logo-mark.svg";
import { SignInFlow } from "../types";


interface SignInCardProps {
    setState: (state: SignInFlow) => void;
}

export const SignInCard = (
    { setState }: SignInCardProps
) => {
    const { signIn } = useAuthActions();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [pending, setPending] = useState(false);
    const [error, setError] = useState("");

    const onPasswordSignIn = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        setPending(true);
        signIn("password", { email, password, flow: "signIn" })
            .catch(() => {
                setError("メールアドレスまたはパスワードが無効です。")
            })
            .finally(() => {
                setPending(false);
            });
    }

    const onProviderSignIn = (value: "github" | "google") => {
        setPending(true);
        signIn(value)
            .finally(() => {
                setPending(false);
            });
    }
    return (
        <Card
            className="
                w-full
                h-full
                p-8
                bg-[#F5F5F5]
                rounded-2xl
                relative
            "
        >
            <Image
                src={logoMark}
                width={100}
                height={100}
                alt=""
                className="absolute top-0 right-0"
            />
            <CardHeader
                className="
                    px-0 
                    pt-0                    
                "
            >
                <p
                    className="
                        text-3xl 
                        font-semibold 
                        mt-8
                        mb-2 
                        text-gray-600
                    "
                >
                    ログイン
                </p>
            </CardHeader>
            {!!error && (
                <div className="
                    bg-destructive/15
                    p-3
                    rounded-md
                    flex
                    items-center
                    gap-x-2
                    text-sm
                    text-destructive
                    mb-6
                ">
                    <TriangleAlert className="size-4" />
                    <p>{error}</p>
                </div>
            )}
            <CardContent className="px-0">
                <form onSubmit={onPasswordSignIn}>
                    <div
                        className="
                            grid 
                            w-full 
                            items-center 
                            gap-4
                        "
                    >
                        <div
                            className="
                                flex 
                                flex-col 
                                space-y-2.5
                            "
                        >
                            <Input
                                disabled={pending}
                                value={email}
                                onChange={(e) => {
                                    setEmail(e.target.value)
                                }}
                                type="email"
                                required
                                id="email"
                                placeholder="メールアドレス"
                                className="w-full"
                            />
                            <Input
                                disabled={pending}
                                value={password}
                                onChange={(e) => {
                                    setPassword(e.target.value)
                                }}
                                type="password"
                                required
                                id="password"
                                placeholder="Password"
                                className="w-full"
                            />
                            <Button
                                type="submit"
                                className="
                                    w-full
                                    rounded-3xl
                                    bg-[#1961CD]
                                "
                                size="lg"
                                disabled={pending}
                            >
                                ログイン
                            </Button>
                        </div>
                    </div>
                </form>
                <Separator
                    className="my-4" />
                <div
                    className="
                        flex
                        flex-col 
                        gap-y-2.5
                    "
                >
                    <Button
                        disabled={pending}
                        onClick={() => onProviderSignIn("google")}
                        variant="outline"
                        size="lg"
                        className="
                            flex                            
                            items-center
                            justify-content
                            w-full
                            relative
                        "
                    >
                        <FcGoogle
                            className="
                                size-5
                                absolute
                                left-2.5
                            "
                        />
                        Googleでログイン
                    </Button>

                    <Button
                        disabled={pending}
                        onClick={() => onProviderSignIn("github")}
                        variant="outline"
                        size="lg"
                        className="
                            flex                            
                            items-center
                            justify-content
                            w-full
                            relative
                        "
                    >
                        <FaGithub
                            className="
                                size-5
                                absolute
                                left-2.5
                            "
                        />
                        GitHubでログイン
                    </Button>
                </div>
                <p
                    className="
                        w-full
                        py-5
                        text-center
                        text-xs                        
                        text-[#FF4085]
                        underline
                        cursor-pointer
                    "
                    onClick={
                        () => {
                            setState("signUp")
                        }
                    }
                >
                    新しいアカウントを作成
                </p>
            </CardContent>
        </Card>
    );
}


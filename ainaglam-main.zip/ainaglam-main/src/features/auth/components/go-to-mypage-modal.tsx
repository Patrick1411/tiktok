import { useCallback } from "react";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog"

import { Button } from "@/components/ui/button";

import { useGoToMypageModal } from "../store/use-go-to-mypage-modal";

export const GoToMypageModal = () => {
    
    const [open, ] = useGoToMypageModal()

    const handleButton = useCallback(() => {
        window.location.href = "https://mypage.ai-na.co.jp";
    }, []);
    return (
        <Dialog open={open}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>サブスクリプションをご契約ください。</DialogTitle>
                </DialogHeader>
                <DialogDescription>
                    AIネイティブアカデミーの月会費を支払いアカウントを有効にしましょう！
                </DialogDescription>
                <div className="flex justify-end">
                    <Button
                        disabled={false}
                        onClick={handleButton}
                    >
                        マイページへ
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}
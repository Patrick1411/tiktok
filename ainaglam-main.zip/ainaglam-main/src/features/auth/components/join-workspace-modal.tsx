import { useMemo } from "react";
import { toast } from "sonner";
import { CopyIcon, Loader2 } from 'lucide-react';
import { useRouter } from "next/navigation";

import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogClose
} from "@/components/ui/dialog"
import { useJoinWorkspaceModal } from "../store/use-join-workspace-modal";
import { useGetAllWorkspaces } from "@/features/workspaces/api/use-get-all-workspaces";
import { useAuthActions } from "@convex-dev/auth/react";

export const JoinWorkspaceModal = () => {
    const { signOut } = useAuthActions();

    const router = useRouter();
    const [open, setOpen] = useJoinWorkspaceModal();
    const { data: workspaces, isLoading: workspacesLoading } = useGetAllWorkspaces();
    const workspace = useMemo(() => workspaces && workspaces.length > 0 ? workspaces[0] : null, [workspaces]);

    const handleJoin = async () => {
        if (workspace?._id) {
            const inviteLink = `${window.location.origin}/join/${workspace._id}`;
            router.replace(inviteLink);
        }
    };

    const handleCopy = () => {
        if (workspace?.joinCode) {
            navigator.clipboard.writeText(workspace.joinCode)
                .then(() => toast.success("招待リンクがクリップボードにコピーされました"))
                .catch(() => toast.error("コピーに失敗しました。もう一度お試しください。"));
        }
    };

    const handleClose = () => {
        setOpen(false);
        signOut();
    }

    if (workspacesLoading) {
        return (
            <div className="flex flex-col bg-[#F5F5F5] h-full items-center justify-center" aria-label="読み込み中">
                <Loader2 className="w-5 h-5 animate-spin text-black" />
            </div>
        );
    }

    if (!workspace) {
        return (
            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>
                            管理者はワークスペースを作成していません。
                        </DialogTitle>
                        <DialogDescription>
                            少しお待ちください！
                            管理者にお問い合わせください。
                        </DialogDescription>
                    </DialogHeader>
                    <DialogClose asChild>
                        <Button
                            variant="outline"
                            onClick={() => handleClose()}
                        >
                            閉じる
                        </Button>
                    </DialogClose>
                </DialogContent>
            </Dialog>
        );
    }

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>
                        {workspace.name}に参加してください。
                    </DialogTitle>
                    <DialogDescription>
                        以下のコードを使ってワークスペースに参加してください。
                        コードをコピークリックしてコードをコピーします。
                        ワークスペース登録ページボタンをクリックしてコードをコピーします。
                    </DialogDescription>
                </DialogHeader>
                <div className="flex flex-col gap-y-4 items-center justify-center py-10">
                    <p className="text-4xl font-bold tracking-widest uppercase">
                        {workspace.joinCode}
                    </p>
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleCopy}
                    >
                        コードをコピー
                        <CopyIcon className="w-4 h-4 ml-2" />
                    </Button>
                </div>
                <div className="flex w-full items-center justify-between">
                    <Button
                        variant="outline"
                        type="button"
                        onClick={handleJoin}
                    >
                        ワークスペース登録ページ
                    </Button>
                    <DialogClose asChild>
                        <Button variant="outline">閉じる</Button>
                    </DialogClose>
                </div>
            </DialogContent>
        </Dialog>
    );
};


import { useState, useCallback, useEffect } from 'react';
import { userCurrentUser } from './user-current-user';

type ResponseType = {
    result: boolean;
    role: string;
    status: boolean;
}

export const useCheckMypage = () => {
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [data, setData] = useState<ResponseType | null>(null);
    const { data: currentUser, isLoading: currentUserLoading } = userCurrentUser();

    const checkMypage = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            
            if (!currentUser?.user.email) {
                throw new Error('ユーザーが見つかりません');
            }
            const url = 'https://backend.ai-na.co.jp/api/check-member-ainaglam';
            const formData = new FormData();
            formData.append('email', currentUser.user.email);

            const response = await fetch(url, {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                throw new Error(`HTTP エラー! ステータス: ${response.status}`);
            }
            
            const result: ResponseType = await response.json();
            setData(result);
            
        } catch (error) {
            setError('ユーザーの確認中にエラーが発生しました');
            console.error('エラーの詳細:', error);
        } finally {
            setIsLoading(false);
        }
    }, [currentUser?.user.email]);

    useEffect(() => {
        if (currentUser?.user.email && !data  && !error) {
            checkMypage();
        }
    }, [currentUser?.user.email, data, isLoading, error, checkMypage]);

    return { data, isLoading: isLoading ?? currentUserLoading, error, checkMypage };
};


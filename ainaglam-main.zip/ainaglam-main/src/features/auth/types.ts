import { Id } from "../../../convex/_generated/dataModel";

export type SignInFlow = "signIn" | "signUp";
export type UploadFileType = "image" | "audio" | "video";
export type CreateMessageValues = {
  channelId: Id<"channels">;
  workspaceId: Id<"workspaces">;
  body: string;
  image?: Id<"_storage"> | undefined;
  audio?: Id<"_storage"> | undefined;
  video?: Id<"_storage"> | undefined;
};
"use client";

import { useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import { Loader } from "lucide-react";

import { useAuthActions } from "@convex-dev/auth/react";

import { useGetWorkspaces } from "@/features/workspaces/api/use-get-workspaces";
import { useCheckMypage } from "@/features/auth/api/use-check-mypage";
import { useCreateWorkspaceModal } from "@/features/workspaces/store/use-create-workspace-modal";
import { useGoToMypageModal } from "@/features/auth/store/use-go-to-mypage-modal";
import { useJoinWorkspaceModal } from "@/features/auth/store/use-join-workspace-modal";


const Home = () => {
  const { signOut } = useAuthActions();
  const router = useRouter();
  const [open, setOpen] = useCreateWorkspaceModal();
  
  const [, setOpenMypage] = useGoToMypageModal();
  
  const [openJoin, setOpenJoin] = useJoinWorkspaceModal();

  const { data, isLoading } = useGetWorkspaces();
  const { data: checkUser, isLoading: checkUserLoading } = useCheckMypage()
  const workspaceId = useMemo(() => data?.[0]?._id, [data]);

  useEffect(() => {
    if (checkUserLoading) return;
    if (!checkUserLoading && !checkUser?.status) {           
      setOpenMypage(true);
      signOut();
    } else {
      if (isLoading) return;
      if (workspaceId) {
        router.replace(`/workspace/${workspaceId}`);
      } else if (!open) {
        if(checkUser?.role === "owner"){
          setOpen(true);
        }else{          
          setOpenJoin(true);
        }        
        console.log("ワークスペース作成モーダルを開く");
      }
    }

  }, [workspaceId, isLoading, open, setOpen, router, checkUser, checkUserLoading, setOpenJoin, setOpenMypage, signOut, openJoin]);
  return (
    <div
      className="
        h-full
        flex
        justify-center
        items-center
      "
    >
      <Loader
        className="
            size-4
            animate-spin
            text-muted-foreground
        "
      />
    </div>

  );
}

export default Home;
"use client";

import { toast } from "sonner";
import { useEffect, useState } from "react";
import { AlertTriangle, Loader } from "lucide-react";


import { useMemberId } from "@/hooks/use-member-id";
import { useWorkspaceId } from "@/hooks/use-workspace-id";

import { useCreateOrGetConversation } from "@/features/conversations/api/use-create-or-get-conversation";

import { Conversation } from "./conversation";
import { Id } from "../../../../../../convex/_generated/dataModel";
import { useCheckMypage } from "@/features/auth/api/use-check-mypage";
import { useGoToMypageModal } from "@/features/auth/store/use-go-to-mypage-modal";
import { useAuthActions } from "@convex-dev/auth/react";

const MemberIdPage = () => {
  const { signOut } = useAuthActions();
  
  const memberId = useMemberId();
  const workspaceId = useWorkspaceId();

  const [conversationId, setConversationId] =
    useState<Id<"conversations"> | null>(null);

  const [, setOpenMypage] = useGoToMypageModal();

  const { mutate, isPending } = useCreateOrGetConversation();


  const { data: checkUser, isLoading: checkUserLoading } = useCheckMypage()
  useEffect(() => {
    if (checkUserLoading) return;
    if (!checkUser?.status) {
      setOpenMypage(true);
      signOut();
    }
  }, [checkUser, checkUserLoading, setOpenMypage, signOut]);

  useEffect(() => {
    mutate(
      {
        workspaceId,
        memberId,
      },
      {
        onSuccess(data) {
          setConversationId(data);
        },
        onError() {
          toast.error("会話を作成または取得できませんでした");
        },
      }
    );
  }, [memberId, workspaceId, mutate]);


  if (isPending) {
    return (
      <div
        className="
          h-full 
          flex 
          items-center 
          justify-center
        "
      >
        <Loader
          className="
            size-6 
            animate-spin 
            text-muted-foreground
          "
        />
      </div>
    );
  }

  if (!conversationId) {
    return (
      <div
        className="
          h-full 
          flex 
          flex-col 
          gap-y-2 
          items-center 
          justify-center
        "
      >
        <AlertTriangle
          className="
            size-6 
            text-muted-foreground
          "
        />
        <span
          className="
            text-sm 
            text-muted-foreground
          "
        >
          会話が見つかりません
        </span>
      </div>
    );
  }

  return <Conversation id={conversationId} />;
};

export default MemberIdPage;

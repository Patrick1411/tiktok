"use client";

import { ChevronLeft, ChevronRight, Loader } from "lucide-react";

import {
    ResizableHandle,
    ResizablePanel,
    ResizablePanelGroup,
} from "@/components/ui/resizable";
import { Profile } from "@/features/members/components/profile";
import { Thread } from "@/features/messages/components/thread";
import { usePanel } from "@/hooks/use-panel";

import { Sidebar } from "./sidebar";
import { Toolbar } from "./toolbar";
import { WorkspaceSidebar } from "./workspace-sidebar";

import { Button } from "@/components/ui/button";
import clsx from "clsx";
import { useState } from "react";
import { Id } from "../../../../convex/_generated/dataModel";

interface WorkspaceIdLayoutProps {
    children: React.ReactNode;
}

const WorkspaceLayout = ({ children }: WorkspaceIdLayoutProps) => {
    const { parentMessageId, profileMemberId, onClose } = usePanel();
    const showPanel = !!parentMessageId || !!profileMemberId;
    const [showMenu, setShowMenu] = useState(false);


    return (
        <div className="h-full">
            <Toolbar />
            <div
                className="
                    flex
                    h-[calc(100vh-40px)]
                "
            >
                <ResizablePanelGroup
                    direction="horizontal"
                    autoSaveId="ca-workspace-layout"
                >
                    <ResizablePanel
                        defaultSize={20}
                        minSize={11}
                        className={clsx(
                            "fixed md:static z-50 h-[calc(100vh-40px)] max-md:translate-x-[-100%] transition-transform bg-[#F5F5F5] !overflow-visible",
                            showMenu && "max-md:translate-x-[0%]",
                        )}
                    >
                        <div className="w-full h-full flex relative">
                            <Sidebar />
                            <WorkspaceSidebar />
                            <div className="relative h-full">
                                <Button variant="default" size="sm" className="md:hidden absolute top-[50%] translate-y-[-50%] left-0 z-50 px-2" onClick={() => setShowMenu(!showMenu)}>
                                    {showMenu ? <ChevronLeft /> : <ChevronRight />}
                                </Button>
                            </div>
                        </div>
                    </ResizablePanel>
                    <ResizableHandle withHandle />
                    <ResizablePanel minSize={20} defaultSize={80} className={showPanel ? "max-md:hidden" : ""}>
                        {children}
                    </ResizablePanel>
                    {showPanel && (
                        <>
                            <ResizableHandle withHandle />
                            <ResizablePanel minSize={20} defaultSize={29}>
                                {parentMessageId ? (
                                    <Thread
                                        messageId={parentMessageId as Id<"messages">}
                                        onClose={onClose}
                                    />
                                ) : profileMemberId ? (
                                    <Profile
                                        memberId={profileMemberId as Id<"members">}
                                        onClose={onClose}
                                    />
                                ) : (
                                    <div
                                        className="
                                            flex 
                                            h-full 
                                            items-center 
                                            justify-center
                                        "
                                    >
                                        <Loader
                                            className="
                                                size-5 
                                                animate-spin 
                                                text-muted-foreground
                                            "
                                        />
                                    </div>
                                )}
                            </ResizablePanel>
                        </>
                    )}
                </ResizablePanelGroup>
            </div>
        </div>
    );
}

export default WorkspaceLayout;
import { usePathname } from "next/navigation";
import { Home, MessageSquare } from "lucide-react";
import { UserButton } from "@/features/auth/components/user-button";
import { WorkspaceSwitcher } from "./workspace-switcher";
import { SidebarButton } from "./sidebar-button";

export const Sidebar = () => {
    const pathname = usePathname();

    return (
        <aside
            className="
                flex-none
                w-[70px]
                h-full
                bg-white
                flex
                flex-col
                gap-y-4
                items-center
                pt-[9px]
                pb-4                
            "
        >
            <WorkspaceSwitcher />
            <SidebarButton icon={Home} label="ホーム" isActive={pathname.includes("/workspace")} />
            <SidebarButton icon={MessageSquare} label="DMs" />
            {/* <SidebarButton icon={Bell} label="活動"/>
            <SidebarButton icon={MoreHorizontal} label="もっと見る"/> */}
            <div
                className="
                    flex
                    flex-col
                    items-center
                    justify-center
                    gap-y-1
                    mt-auto 
                "
            >
                <UserButton />
            </div>
        </aside>
    );
}
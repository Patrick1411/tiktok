import {
    AlertTriangle,
    HashIcon,
    Loader,
    MessageSquareText,
} from "lucide-react";

import { useGetMembers } from "@/features/members/api/use-get-members";
import { useGetChannels } from "@/features/channels/api/use-get-channels";
import { useCurrentMember } from "@/features/members/api/use-current-member";
import { useGetWorkspace } from "@/features/workspaces/api/use-get-workspace";
import { useCreateChannelModal } from "@/features/channels/store/use-create-channel-modal";

import { useChannelId } from "@/hooks/use-channel-id";
import { useWorkspaceId } from "@/hooks/use-workspace-id"
import { useMemberId } from "@/hooks/use-member-id";

import { UserItem } from "./user-item";
import { WorkspaceHeader } from "./workspace-header";
import { SidebarItem } from "./sidebar-item";
import { WorkspaceSection } from "./workspace-section";
import { useGetUnreads } from "@/features/messages/api/use-get-unreads";
import { Id } from "../../../../convex/_generated/dataModel";
import { useGetConversations } from "@/features/conversations/api/use-get-conversations";



type Channel = {
    _id: Id<"channels">;
    _creationTime: number;
    workspaceId: Id<"workspaces">;
    name: string;
};

type ChannelWithCount = Channel & {
    unreadCount: number;
};

export const WorkspaceSidebar = () => {
    const memberId = useMemberId()
    const channelId = useChannelId()
    const workspaceId = useWorkspaceId();

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const [_open, setOpen] = useCreateChannelModal();

    const { data: member, isLoading: memberLoading } = useCurrentMember({ workspaceId });
    const { data: workspace, isLoading: workspaceLoading } = useGetWorkspace({ id: workspaceId });
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { data: channels, isLoading: channelsLoading } = useGetChannels({ workspaceId });
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { data: members, isLoading: membersLoading } = useGetMembers({ workspaceId });

    const { unreadCounts, isLoading: unreadLoading } = useGetUnreads({ workspaceId })
    const { conversations, currentMemberId } = useGetConversations({ workspaceId });

    console.log("it is me", memberId)


    if (workspaceLoading || memberLoading || unreadLoading) {
        return (
            <div
                className="
                    flex-[1_1_0]
                    flex
                    flex-col
                    bg-[#150b0b]
                    h-full
                    items-center
                    justify-center
                "
            >
                <Loader
                    className="
                        size-5
                        animate-spin
                        text-black
                    "
                />
            </div>
        )
    }

    if (!workspace || !member) {
        return (
            <div
                className="
                    flex-[1_1_0]
                    flex
                    flex-col
                    gap-y-2
                    bg-[#F5F5F5]
                    h-full
                    items-center
                    justify-center
                "
            >
                <AlertTriangle
                    className="
                        size-5
                        text-red-500
                    "
                />
                <p className="text-red-500 text-sm">
                    ワークスペースが見つかりません。
                </p>
            </div>
        )
    }


    const channelsWithCount: ChannelWithCount[] = channels?.map((channel) => {
        const unreadItem = unreadCounts?.find((item) => item.id === channel._id && item.type === "channel");
        return {
            ...channel,
            unreadCount: unreadItem ? unreadItem.count : 0,
        };
    }) ?? [];

    const membersWithCount = members?.map((member) => {
        const matchingConversation = conversations?.find((c) =>
            (c.memberOneId === member._id && c.memberOneId !== currentMemberId) || (c.memberTwoId === member._id && c.memberTwoId !== currentMemberId)
        );

        if (matchingConversation) {
            const unreadItem = unreadCounts?.find(
                (item) => item.id === matchingConversation._id && item.type === "conversation"
            );

            return {
                ...member,
                unreadCount: unreadItem ? unreadItem.count : 0,
            };
        }

        return {
            ...member,
            unreadCount: 0,
        };
    });

    return (
        <div
            className="
                flex-[1_1_0]
                flex
                flex-col
                gap-y-2
                bg-[#f5f5f5]
                h-full
            "
        >
            <WorkspaceHeader
                workspace={workspace}
                isAdmin={member.role === "admin"}
            />
            <div
                className="
                    flex
                    flex-col
                    px-2
                    mt-3               
                "
            >
                <SidebarItem
                    label="コメント"
                    icon={MessageSquareText}
                    id="comments"
                    variant={(channelId === undefined && memberId === undefined) ? "active" : "default"}
                />
                {/* <SidebarItem
                    label="下書き & 送信"
                    icon={SendHorizonal}
                    id="drafts"
                /> */}
            </div>
            <WorkspaceSection
                label="スレッド"
                hint="新しいチャンネル"
                onNew={member.role === "admin" ? () => setOpen(true) : undefined}
            >
                {channelsWithCount?.map((item) => (
                    <SidebarItem
                        key={item._id}
                        icon={HashIcon}
                        label={item.name}
                        id={item._id}
                        unreadCount={item.unreadCount}
                        variant={channelId === item._id ? "active" : "default"}
                    />
                ))}
            </WorkspaceSection>
            <WorkspaceSection
                label="メンバー(ダイレクトメッセージ)"
                hint="新しいダイレクトメッセージ"
                onNew={() => { }}
            >
                {membersWithCount?.map((item) => (
                    <UserItem
                        key={item._id}
                        id={item._id}
                        label={item.user.displayName || item.user.name}
                        image={item.user.image || undefined}
                        variant={item._id === memberId ? "active" : "default"}
                        unreadCount={item.unreadCount}
                    />
                ))}
            </WorkspaceSection>
        </div>
    );
}
import { LucideIcon } from "lucide-react";
import { IconType } from "react-icons/lib";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface SidebarButtonProps {
    icon: LucideIcon | IconType
    label: string;
    isActive?: boolean
}

export const SidebarButton = ({
    icon: Icon,
    label,
    isActive
}: SidebarButtonProps) => {
    return (
        <div
            className="
                flex
                flex-col
                items-center
                justify-center
                gap-y-0.5
                cursor-pointer
                group
            "
        >
            <Button
                variant="transparent"
                className={cn(
                    "size-9 p-2 group-hover:bg-sky-500",
                    isActive && "bg-sky-500/20"
                )}
            >
                <Icon
                    className="
                        size-5 
                        text-black
                        group-hover:text-white
                        transition-all
                    "
                />
            </Button>
            <span
                className="
                    text-[11px]
                    text-black
                    group-hover:text-sky-500
                "
            >
                {label}
            </span>
        </div>
    );
}
"use client";

import { Loader, MessageSquareText, TriangleAlert } from "lucide-react";


import { Header } from "./header";

import { CommentMessageList } from "@/components/comment-message-list";

import { useEffect } from "react";
import { useCheckMypage } from "@/features/auth/api/use-check-mypage";
import { useGoToMypageModal } from "@/features/auth/store/use-go-to-mypage-modal";
import { useAuthActions } from "@convex-dev/auth/react";
import { useGetComments } from "@/features/messages/api/use-get-comments";

const ChannelIdPage = () => {
  const { signOut } = useAuthActions();

  const [, setOpenMypage] = useGoToMypageModal();

  const { data: comments, isLoading: commetsLoading } = useGetComments();


  const { data: checkUser, isLoading: checkUserLoading } = useCheckMypage()
  useEffect(() => {
    if (checkUserLoading) return;
    if (!checkUser?.status) {
      setOpenMypage(true);
      signOut();
    }
  }, [checkUser, setOpenMypage, signOut, checkUserLoading]);

  if (commetsLoading || checkUserLoading) {
    return (
      <div
        className="
          h-full 
          flex 
          flex-1 
          items-center 
          justify-center
        "
      >
        <Loader
          className="
            animate-spin 
            size-5 
            text-muted-foreground
          "
        />
      </div>
    );
  }
  
  if (!comments) {
    return (
      <div
        className="
          h-full 
          flex 
          flex-1 
          flex-col 
          gap-y-2 
          items-center 
          justify-center
        "
      >
        <TriangleAlert
          className="size-5 text-destructive"
        />
        <span
          className="
            text-sm 
            text-muted-foreground
          "
        >
          コメントが見つかりません。
        </span>
      </div>
    );
  }

  

  return (
    <div className="flex flex-col h-full">
      <Header title="コメント" icon={MessageSquareText}/>
      <CommentMessageList 
        comments={comments}
      />
    </div>
  );
};

export default ChannelIdPage;

import { useState } from "react";
import { Info, Search } from "lucide-react";
import { useRouter } from "next/navigation";

import { useGetWorkspace } from "@/features/workspaces/api/use-get-workspace";
import { useGetChannels } from "@/features/channels/api/use-get-channels";
import { useGetMembers } from "@/features/members/api/use-get-members";
import { Button } from "@/components/ui/button";
import { useWorkspaceId } from "@/hooks/use-workspace-id";

import {
    CommandDialog,
    CommandEmpty,
    CommandGroup,
    CommandInput,
    CommandItem,
    CommandList,
    CommandSeparator,
} from "@/components/ui/command"


export const Toolbar = () => {
    const router = useRouter();
    const workspaceId = useWorkspaceId();
    const [open, setOpen] = useState(false);

    const { data } = useGetWorkspace({ id: workspaceId });
    const { data: channels } = useGetChannels({ workspaceId });
    const { data: members } = useGetMembers({ workspaceId });

    const onChannelClick = (channelId: string) => {
        setOpen(false);
        router.push(`/workspace/${workspaceId}/channel/${channelId}`);
    };

    const onMemberClick = (memberId: string) => {
        setOpen(false);
        router.push(`/workspace/${workspaceId}/member/${memberId}`);
    };

    return (
        <div
            className="
                bg-[#481349]
                flex
                items-center
                justify-between
                h-10
                p-1.5
            "
        >
            <div className="flex-1" />
            <div
                className="
                    min-w-[280px]
                    max-[642px]
                    grow-[2]
                    shrink
                "
            >
                <Button
                    onClick={() => setOpen(true)}
                    size="sm"
                    className="
                        text-sm
                        bg-accent/25
                        hover:bg-accent-25
                        w-full
                        justify-start
                        h-7
                        px-2
                    "
                >
                    <Search
                        className="
                            size-4
                            text-white
                            text-xs
                        "
                    />
                    <span
                        className="
                            text-white
                            text-xs
                        "
                    >
                        検索ワークスペース({data?.name})
                    </span>
                </Button>
                <CommandDialog open={open} onOpenChange={setOpen}>
                    <CommandInput placeholder="Search..." />
                    <CommandList>
                        <CommandEmpty> 結果が見つかりませんでした。</CommandEmpty>
                        <CommandGroup heading="スレッド">
                            {channels?.map((channel) => (
                                <CommandItem
                                    key={channel._id}
                                    onSelect={() => onChannelClick(channel._id)}
                                >
                                    {channel.name}
                                </CommandItem>
                            ))}
                        </CommandGroup>
                        <CommandSeparator />
                        <CommandGroup heading="会員">
                            {members?.map((member) => (
                                <CommandItem
                                    key={member._id}
                                    onSelect={() => onMemberClick(member._id)}
                                >
                                    {member.user.name}
                                </CommandItem>
                            ))}
                        </CommandGroup>
                    </CommandList>
                </CommandDialog>
            </div>
            <div
                className="
                    ml-auto
                    flex-1
                    flex
                    items-center
                    justify-end
                "
            >
                <Button variant="transparent" size="iconSm">
                    <Info className="size-5 text-white" />
                </Button>
            </div>
        </div>
    );
} 

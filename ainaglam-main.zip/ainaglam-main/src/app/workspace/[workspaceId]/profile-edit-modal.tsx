"use client"

import { useState, useRef, FormEvent } from "react"
import { toast } from "sonner"
import { Upload } from 'lucide-react'

import { useConfirm } from "@/hooks/use-confirm"
import { useUpdateUser } from "@/features/users/api/use-update-user"
import { useGenerateUploadUrl } from "@/features/upload/api/use-generate-upload-url"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogClose,
    DialogFooter
} from "@/components/ui/dialog"
import { Id } from "../../../../convex/_generated/dataModel"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useRemoveFile } from "@/features/remove/api/use-remove-file"

interface ProfileEditModalProps {
    open: boolean
    setOpen: (open: boolean) => void
    initialValues?: {
        fullName?: string
        displayName?: string
        photoUrl?: string
    }
}

type UpdateProfileValues = {
    name: string;
    displayName: string;
    image?: Id<"_storage"> | undefined;
};

export const ProfileEditModal = ({
    open,
    setOpen,
    initialValues = {}
}: ProfileEditModalProps) => {
    
    
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const [ConfirmDialog, confirm] = useConfirm(
        "正しいですか？",
        "この行為は元に戻すことはできません。"
    );
    const fileInputRef = useRef<HTMLInputElement>(null)

    const [formData, setFormData] = useState({
        fullName: initialValues.fullName || "",
        displayName: initialValues.displayName || "",
        photoUrl: initialValues.photoUrl || ""
    })

    const [isPending, setIsPending] = useState(false);
    const { mutate: updateProfile } = useUpdateUser()
    const { mutate: removeUploadFile } = useRemoveFile();
    const { mutate: generateUploadUrl } = useGenerateUploadUrl();


    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }))
    }

    const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0]
        if (file) {
            const url = URL.createObjectURL(file)
            setFormData(prev => ({
                ...prev,
                photoUrl: url
            }))
        }
    }

    const prevStorageFile = async () => {
        if (initialValues.photoUrl) {
            if (initialValues.photoUrl.includes("convex.cloud")) {
                await removeUploadFile({}, { throwError: true });
            }
        }

    }

    const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        try {
            setIsPending(true);

            const values: UpdateProfileValues = {
                name: formData.fullName,
                displayName: formData.displayName,
                image: undefined,
            };

            const imageInput = fileInputRef.current;
            if (imageInput && imageInput.files && imageInput.files[0]) {

                const image = imageInput.files[0];
                
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const prevFile = prevStorageFile();
                const url = await generateUploadUrl({}, { throwError: true });

                if (!url) {
                    throw new Error("URLが見つかりません");
                }

                const result = await fetch(url, {
                    method: "POST",
                    headers: { "Content-Type": image.type },
                    body: image,
                });

                if (!result.ok) {
                    throw new Error("画像のアップロードに失敗しました");
                }

                const { storageId } = await result.json();

                values.image = storageId;
            }

            await updateProfile(values, { throwError: true });
            toast.success("プロフィールが更新されました");
            setOpen(false);
        } catch (error) {
            toast.error("プロフィールの更新に失敗しました");
            console.log(error);
        } finally {
            setIsPending(false);
        }
    };

    return (
        <>
            <ConfirmDialog />
            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="sm:max-w-[600px]">
                    <DialogHeader>
                        <DialogTitle>プロフィールを編集する</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="grid grid-cols-[2fr,1fr] gap-6">
                            <div className="space-y-4">
                                <div>
                                    <Label htmlFor="name">氏名</Label>
                                    <Input
                                        id="name"
                                        name="name"
                                        value={formData.fullName}
                                        onChange={handleInputChange}
                                        maxLength={80}
                                    />
                                </div>

                                <div>
                                    <Label htmlFor="displayName">ディスプレイ名</Label>
                                    <Input
                                        id="displayName"
                                        name="displayName"
                                        value={formData.displayName}
                                        onChange={handleInputChange}
                                    />
                                    <p className="text-sm text-muted-foreground mt-1">
                                        これはあなたのファーストネームでも、ニックネームでも構いません。あなたが人々にどのように呼ばれたいかに応じてください。
                                    </p>
                                </div>
                            </div>

                            <div className="space-y-4">
                                <div>
                                    <Label>プロフィール写真</Label>
                                    <div className="mt-2 flex flex-col items-center gap-4">
                                        <div className="relative h-40 w-40 rounded-md bg-orange-500 overflow-hidden">
                                            <Avatar
                                                className="
                                                    size-5 
                                                    rounded-md 
                                                    mr-1 
                                                    hover:bg-white  
                                                    h-full w-full object-cover
                                                                          
                                                "
                                            >
                                                <AvatarImage className="rounded-md" src={formData.photoUrl} />
                                                <AvatarFallback
                                                    className="
                                                    rounded-md
                                                    bg-sky-400 
                                                    text-white
                                                    hover:bg-white
                                                    h-full w-full object-cover
                                                "
                                                >
                                                    <div className="h-full w-full flex items-center justify-center">
                                                        <div className="h-24 w-24 rounded-full bg-orange-200" />
                                                    </div>
                                                </AvatarFallback>
                                            </Avatar>
                                        </div>
                                        <input
                                            type="file"
                                            id="image"
                                            name="image"
                                            ref={fileInputRef}
                                            className="hidden"
                                            accept="image/*"
                                            onChange={handlePhotoUpload}
                                        />
                                        <Button
                                            type="button"
                                            variant="outline"
                                            onClick={() => fileInputRef.current?.click()}
                                        >
                                            <Upload className="mr-2 h-4 w-4" />
                                            写真をアップロード
                                        </Button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <DialogFooter>
                            <DialogClose asChild>
                                <Button type="button" variant="outline" disabled={isPending}>
                                    閉じる
                                </Button>
                            </DialogClose>
                            <Button type="submit" disabled={isPending}>
                                保存
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        </>
    );
};
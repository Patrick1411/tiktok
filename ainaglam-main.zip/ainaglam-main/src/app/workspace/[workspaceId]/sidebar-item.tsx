import Link from "next/link";
import { LucideIcon } from "lucide-react";
import { IconType } from "react-icons/lib";
import { cva, type VariantProps } from "class-variance-authority";

import { Button } from "@/components/ui/button";
import { useWorkspaceId } from "@/hooks/use-workspace-id";
import { cn } from "@/lib/utils";

const sidebarItemVariants = cva(
    "flex items-center p-1.5 justify-start font-normal h-7 px-[18px] text-sm overflow-hidden hover:bg-blue-400/100",
    {
        variants: {
            variant: {
                default: "text-black",
                active: "text-black bg-blue-600 hover:bg-blue-400/100",
            },
        },
        defaultVariants: {
            variant: "default",
        }
    },
);

interface SidebarItemProps {
    label: string;
    id: string;
    icon: LucideIcon | IconType;
    variant?: VariantProps<typeof sidebarItemVariants>["variant"];
    unreadCount?: number;
}

export const SidebarItem = ({
    label,
    id,
    icon: Icon,
    variant,
    unreadCount = 0
}: SidebarItemProps) => {
    const workspaceId = useWorkspaceId();
    
    return (
        <Button
            variant="transparent"
            size="sm"
            className={cn(sidebarItemVariants({ variant: variant }))}
            asChild
        >
            {id !== "comments" ? (<Link
                href={`/workspace/${workspaceId}/channel/${id}`}
            >
                <Icon className="size-3.5 mr-1 shrink-0" />
                <span className="text-sm truncate">{label}</span>
                {unreadCount !== 0 && (
                    <div
                        className=" 
                        bg-red-500
                        w-4
                        h-4
                        rounded-full
                        flex
                        items-center
                        justify-center
                        ml-auto
                    "
                    >
                        <span className="text-sm font-semibold truncate text-white">{unreadCount}</span>
                    </div>
                )}


            </Link>) :
                <Link
                    href={`/workspace/${workspaceId}/comments`}
                >
                    <Icon className="size-3.5 mr-1 shrink-0" />
                    <span className="text-sm truncate">{label}</span>
                </Link>}

        </Button>
    );
}

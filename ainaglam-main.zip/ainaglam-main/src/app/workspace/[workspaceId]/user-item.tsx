import Link from "next/link";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { useWorkspaceId } from "@/hooks/use-workspace-id";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

import { Id } from "../../../../convex/_generated/dataModel";

const userItemVariants = cva(
    "flex items-center p-1.5 justify-start font-normal h-7 px-4 text-sm overflow-hidden hover:bg-blue-400/100",
    {
        variants: {
            variant: {
                default: "text-black",
                active: "text-black bg-blue-600 hover:bg-blue-400/100",
            },
        },
        defaultVariants: {
            variant: "default",
        }
    },
);

interface UserItemProps {
    id: Id<"members">;
    label?: string;
    image?: string;
    variant?: VariantProps<typeof userItemVariants>["variant"];
    unreadCount?: number;
};

export const UserItem = ({
    id,
    label = "メンバー",
    image,
    variant,
    unreadCount
}: UserItemProps) => {
    const workspaceId = useWorkspaceId();
    const avatarFallback = label.charAt(0).toUpperCase();
    return (
        <Button
            variant="transparent"
            size="sm"
            className={cn(userItemVariants({ variant: variant }))}
            asChild
        >
            <Link
                href={`/workspace/${workspaceId}/member/${id}`}
            >
                <Avatar
                    className="
                        size-5 
                        rounded-md 
                        mr-1 
                        hover:bg-white                        
                    "
                >
                    <AvatarImage className="rounded-md" src={image} />
                    <AvatarFallback
                        className="
                            rounded-md
                            bg-sky-400 
                            text-white
                            hover:bg-white
                        "
                    >
                        {avatarFallback}
                    </AvatarFallback>
                </Avatar>
                <span className="text-sm truncate">{label}</span>
                {unreadCount !== 0 && (
                    <div
                        className=" 
                        bg-red-500
                        w-4
                        h-4
                        rounded-full
                        flex
                        items-center
                        justify-center
                        ml-auto
                    "
                    >
                        <span className="text-sm font-semibold truncate text-white">{unreadCount}</span>
                    </div>
                )}
            </Link>
        </Button>
    );
}
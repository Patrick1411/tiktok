import { v } from "convex/values";
import { auth } from "./auth";
import { Id } from "./_generated/dataModel";
import { mutation, query, QueryCtx } from "./_generated/server";

const populateUser = (ctx: QueryCtx, userId: Id<"users">) => {
    return ctx.db.get(userId);
};

export const current = query({
    args: {},
    handler: async (ctx) => {
        const userId = await auth.getUserId(ctx);

        if (userId === null) {
            return null;
        }

        const user = await ctx.db.get(userId);

        if (!user) {
            return null;
        }

        const userWithImage = {
            ...user,
            image: user.image
                ? user.image.includes("http")
                    ? user.image
                    : await ctx.storage.getUrl(user.image)
                : undefined,
        };

        return {user: userWithImage};
    }
});

export const update = mutation({
    args: {
        name: v.string(),
        displayName: v.string(),
        image: v.optional(v.id("_storage")),
    },
    handler: async (ctx, args) => {
        const userId = await auth.getUserId(ctx);
        if (!userId) {
            throw new Error("ユーザーは認証されていません。");
        }

        await ctx.db.patch(userId, {
            name: args.name,
            displayName: args.displayName,
            image: args.image,
        });

        return userId;
    },
});
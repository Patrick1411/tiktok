import { v } from "convex/values";
import { paginationOptsValidator } from "convex/server";

import { Doc, Id } from "./_generated/dataModel";
import { mutation, query, QueryCtx, MutationCtx } from "./_generated/server";
import { auth } from "./auth";
interface Message {
  _id: Id<"messages">;
  body?: Doc<"messages">["body"];
  image?: Id<"_storage"> | undefined;
  audio?: Id<"_storage"> | undefined;
  video?: Id<"_storage"> | undefined;
  channelId?: Id<"channels"> | undefined;
  conversationId?: Id<"conversations"> | undefined;
  memberId: Id<"members">;
  workspaceId: Id<"workspaces">;
  parentMessageId?: Id<"messages">;
  _creationTime: number;
  updatedAt?: number;
}


const populateThread = async (ctx: QueryCtx, messageId: Id<"messages">) => {
  const messages = await ctx.db
    .query("messages")
    .withIndex("by_parent_message_id", (q) =>
      q.eq("parentMessageId", messageId),
    )
    .collect();

  if (messages.length === 0) {
    return {
      count: 0,
      image: undefined,
      timestamp: 0,
      name: "",
    };
  }

  const lastMessage = messages[messages.length - 1];
  const lastMessageMember = await populateMember(ctx, lastMessage.memberId);

  if (!lastMessageMember) {
    return {
      count: 0,
      image: undefined,
      timestamp: 0,
      name: "",
    };
  }

  const lastMessageUser = await populateUser(ctx, lastMessageMember.userId);


  return {
    count: messages.length,
    image: (lastMessageUser?.image && !lastMessageUser?.image.includes("http"))
      ? await ctx.storage.getUrl(lastMessageUser?.image)
      : (lastMessageUser?.image && lastMessageUser?.image.includes("http"))
        ? lastMessageUser?.image
        : undefined,
    timestamp: lastMessage._creationTime,
    name: lastMessageUser?.displayName,
  };
};

const populateChannel = async (ctx: QueryCtx, channelId: Id<"channels">) => {
  const channel = await ctx.db.get(channelId);
  return channel;
};
const populateReactions = (ctx: QueryCtx, messageId: Id<"messages">) => {
  return ctx.db
    .query("reactions")
    .withIndex("by_message_id", (q) => q.eq("messageId", messageId))
    .collect();
};

const populateUser = (ctx: QueryCtx, userId: Id<"users">) => {
  return ctx.db.get(userId);
};

const getMediaUrl = async (ctx: QueryCtx, mediaId: Id<"_storage"> | undefined) =>
  mediaId ? await ctx.storage.getUrl(mediaId) : undefined;


const deleteMediaIfExists = async (ctx: MutationCtx, mediaId: Id<"_storage"> | null | undefined) => {
  if (mediaId) {
    await ctx.storage.delete(mediaId);
  }
};

const populateMember = (ctx: QueryCtx, memberId: Id<"members">) => {
  return ctx.db.get(memberId);
};

const getMember = async (
  ctx: QueryCtx,
  workspaceId: Id<"workspaces">,
  userId: Id<"users">,
) => {
  return ctx.db
    .query("members")
    .withIndex("by_workspace_id_user_id", (q) =>
      q.eq("workspaceId", workspaceId).eq("userId", userId),
    )
    .unique();
};

export const remove = mutation({
  args: {
    id: v.id("messages"),
  },
  handler: async (ctx, args) => {
    const userId = await auth.getUserId(ctx);
    if (!userId) {
      throw new Error("ユーザーは認証されていません。");
    }

    const message = await ctx.db.get(args.id);

    if (!message) {
      throw new Error("メッセージが見つかりません");
    }

    const member = await getMember(ctx, message.workspaceId, userId);

    if (!member || member._id !== message.memberId) {
      throw new Error("ユーザーは認証されていません。");
    }
    await Promise.all([
      deleteMediaIfExists(ctx, message.image ?? null),
      deleteMediaIfExists(ctx, message.audio ?? null),
      deleteMediaIfExists(ctx, message.video ?? null)
    ]);

    await ctx.db.delete(args.id);

    return args.id;
  },
});

export const update = mutation({
  args: {
    id: v.id("messages"),
    body: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await auth.getUserId(ctx);
    if (!userId) {
      throw new Error("ユーザーは認証されていません。");
    }

    const message = await ctx.db.get(args.id);

    if (!message) {
      throw new Error("メッセージが見つかりません");
    }

    const member = await getMember(ctx, message.workspaceId, userId);

    if (!member || member._id !== message.memberId) {
      throw new Error("スレッドが見つかりません");
    }

    await ctx.db.patch(args.id, {
      body: args.body,
      updatedAt: Date.now(),
    });

    return args.id;
  },
});

export const getById = query({
  args: {
    id: v.id("messages"),
  },
  handler: async (ctx, args) => {
    const userId = await auth.getUserId(ctx);

    if (!userId) {
      return null;
    }

    const message = await ctx.db.get(args.id);

    if (!message) {
      return null;
    }

    const currentMember = await getMember(ctx, message.workspaceId, userId);

    if (!currentMember) {
      return null;
    }

    const member = await populateMember(ctx, message.memberId);

    if (!member) {
      return null;
    }

    const user = await populateUser(ctx, member.userId);

    if (!user) {
      return null;
    }

    const reactions = await populateReactions(ctx, message._id);

    const reactionsWithCounts = reactions.map((reaction) => {
      return {
        ...reaction,
        count: reactions.filter((r) => r.value === reaction.value).length,
      };
    });

    const dedupedReactions = reactionsWithCounts.reduce(
      (acc, reaction) => {
        const existingReaction = acc.find((r) => r.value === reaction.value);

        if (existingReaction) {
          existingReaction.memberIds = Array.from(
            new Set([...existingReaction.memberIds, reaction.memberId]),
          );
        } else {
          acc.push({
            ...reaction,
            memberIds: [reaction.memberId],
          });
        }

        return acc;
      },
      [] as (Doc<"reactions"> & {
        count: number;
        memberIds: Id<"members">[];
      })[],
    );

    const reactionsWithoutMemberIdProperty = dedupedReactions.map(
      ({ memberId, ...rest }) => rest,
    );
    const [image, audio, video] = await Promise.all([
      getMediaUrl(ctx, message.image),
      getMediaUrl(ctx, message.audio),
      getMediaUrl(ctx, message.video)
    ]);
    return {
      ...message,
      image,
      audio,
      video,
      user,
      member,
      reactions: reactionsWithoutMemberIdProperty,
    };
  },
});



const groupMessages = (allMessages: Message[]) => {
  const groupedMessages: Record<string, { parent: Message | null; children: Message[] }> = {};
  allMessages.forEach((message) => {
    const parentId = message.parentMessageId?.toString() || "root";
    if (parentId !== "root") {
      if (!groupedMessages[parentId]) {
        groupedMessages[parentId] = { parent: null, children: [] };
      }
      groupedMessages[parentId].children.push(message);
    }
  });

  const groupKeys = Object.keys(groupedMessages);
  allMessages.forEach((message) => {
    groupKeys.map((key) => {
      if (key === message._id) {
        groupedMessages[key].parent = message;
      }
    });
  });

  return groupedMessages;
}

const processMessage = async (ctx: QueryCtx, message: Message, isParent = false) => {
  try {
    const member = await populateMember(ctx, message.memberId);
    const user = member ? await populateUser(ctx, member.userId) : null;

    if (!member || !user) {
      return null;
    }

    const userWithImage = {
      ...user,
      image: user.image && !user.image.includes("http")
        ? await ctx.storage.getUrl(user.image)
        : user.image && user.image.includes("http")
          ? user.image
          : undefined,
    };

    const reactions = await populateReactions(ctx, message._id);

    const [image, audio, video] = await Promise.all([
      getMediaUrl(ctx, message.image),
      getMediaUrl(ctx, message.audio),
      getMediaUrl(ctx, message.video)
    ]);

    const reactionsWithCounts = reactions.map((reaction) => ({
      ...reaction,
      count: reactions.filter((r) => r.value === reaction.value).length,
    }));

    const dedupedReactions = reactionsWithCounts.reduce(
      (acc, reaction) => {
        const existingReaction = acc.find(
          (r) => r.value === reaction.value
        );

        if (existingReaction) {
          existingReaction.memberIds = Array.from(
            new Set([...existingReaction.memberIds, reaction.memberId])
          );
        } else {
          acc.push({
            ...reaction,
            memberIds: [reaction.memberId],
          });
        }

        return acc;
      },
      [] as (Doc<"reactions"> & {
        count: number;
        memberIds: Id<"members">[];
      })[]
    );

    const reactionsWithoutMemberIdProperty = dedupedReactions.map(
      ({ memberId, ...rest }) => rest
    );

    const processedMessage = {
      ...message,
      image,
      audio,
      video,
      member,
      channel: undefined,
      user: userWithImage,
      reactions: reactionsWithoutMemberIdProperty,
    };

    if (isParent) {
      const channel = message.channelId ? await populateChannel(ctx, message.channelId) : undefined;

      return {
        ...processedMessage,
        channel: channel,
      };
    }

    return processedMessage;
  } catch (error) {
    console.error(`Error processing message ID: ${message._id}`, error);
    return null; // Handle error gracefully  
  }
}

export const getComments = query({
  args: {},
  handler: async (ctx) => {
    const allMessages = await ctx.db
      .query("messages")
      .withIndex("by_parent_message_id")
      .order("desc")
      .collect();
    const groupedMessages = groupMessages(allMessages);
    const groupKeys = Object.keys(groupedMessages);

    const processedGroupedMessages = await Promise.all(
      groupKeys.map(async (key) => {
        const processedChildren = await Promise.all(
          groupedMessages[key].children.map(async (message) => {
            try {
              return await processMessage(ctx, message);
            } catch (error) {
              console.error('子メッセージの処理中にエラーが発生しました:', error);
              return null;
            }
          })
        );



        const processedParent = await Promise.all(
          (Array.isArray(groupedMessages[key].parent)
            ? groupedMessages[key].parent
            : [groupedMessages[key].parent]
          ).map(async (message) => {
            try {
              return await processMessage(ctx, message);
            } catch (error) {
              console.error('子メッセージの処理中にエラーが発生しました:', error);
              return null;
            }
          })
        );

        return {
          ...groupedMessages[key],
          children: processedChildren.filter(Boolean).reverse(),
          parent: processedParent.filter(Boolean)[0],
        };
      })
    );

    return Object.fromEntries(
      processedGroupedMessages.map((group, index) => [groupKeys[index], group])
    );
  },
});


export const get = query({
  args: {
    channelId: v.optional(v.id("channels")),
    conversationId: v.optional(v.id("conversations")),
    parentMessageId: v.optional(v.id("messages")),
    paginationOpts: paginationOptsValidator,
  },
  handler: async (ctx, args) => {
    const userId = await auth.getUserId(ctx);

    if (!userId) {
      throw new Error("ユーザーは認証されていません。");
    }

    let _conversationId = args.conversationId;

    if (!args.conversationId && !args.channelId && args.parentMessageId) {
      const parentMessage = await ctx.db.get(args.parentMessageId);

      if (!parentMessage) {
        throw new Error("親メッセージが見つかりません");
      }

      _conversationId = parentMessage.conversationId;
    }

    const results = await ctx.db
      .query("messages")
      .withIndex("by_channel_id_parent_message_id_conversation_id", (q) =>
        q
          .eq("channelId", args.channelId)
          .eq("parentMessageId", args.parentMessageId)
          .eq("conversationId", _conversationId),
      )
      .order("desc")
      .paginate(args.paginationOpts);

    return {
      ...results,
      page: (
        await Promise.all(
          results.page.map(async (message) => {
            const member = await populateMember(ctx, message.memberId);
            const user = member ? await populateUser(ctx, member.userId) : null;


            if (!member || !user) {
              return null;
            }

            const userWithImage = {
              ...user,
              image: (user?.image && !user?.image.includes("http"))
                ? await ctx.storage.getUrl(user?.image)
                : (user?.image && user?.image.includes("http"))
                  ? user?.image
                  : undefined,
            };

            const reactions = await populateReactions(ctx, message._id);
            const thread = await populateThread(ctx, message._id);

            const [image, audio, video] = await Promise.all([
              getMediaUrl(ctx, message.image),
              getMediaUrl(ctx, message.audio),
              getMediaUrl(ctx, message.video)
            ]);

            const reactionsWithCounts = reactions.map((reaction) => {
              return {
                ...reaction,
                count: reactions.filter((r) => r.value === reaction.value)
                  .length,
              };
            });

            const dedupedReactions = reactionsWithCounts.reduce(
              (acc, reaction) => {
                const existingReaction = acc.find(
                  (r) => r.value === reaction.value,
                );

                if (existingReaction) {
                  existingReaction.memberIds = Array.from(
                    new Set([...existingReaction.memberIds, reaction.memberId]),
                  );
                } else {
                  acc.push({
                    ...reaction,
                    memberIds: [reaction.memberId],
                  });
                }

                return acc;
              },
              [] as (Doc<"reactions"> & {
                count: number;
                memberIds: Id<"members">[];
              })[],
            );

            const reactionsWithoutMemberIdProperty = dedupedReactions.map(
              ({ memberId, ...rest }) => rest,
            );
            return {
              ...message,
              image,
              audio,
              video,
              member,
              user: userWithImage,
              reactions: reactionsWithoutMemberIdProperty,
              threadCount: thread.count,
              threadImage: thread.image,
              threadName: thread.name,
              threadTimestamp: thread.timestamp,
            };
          }),
        )
      ).filter(
        (message): message is NonNullable<typeof message> => message !== null,
      ),
    };
  },
});

export const create = mutation({
  args: {
    body: v.string(),
    image: v.optional(v.id("_storage")),
    audio: v.optional(v.id("_storage")),
    video: v.optional(v.id("_storage")),
    workspaceId: v.id("workspaces"),
    channelId: v.optional(v.id("channels")),
    conversationId: v.optional(v.id("conversations")),
    parentMessageId: v.optional(v.id("messages")),
  },
  handler: async (ctx, args) => {
    const userId = await auth.getUserId(ctx);

    if (!userId) {
      throw new Error("ユーザーは認証されていません。");
    }

    const member = await getMember(ctx, args.workspaceId, userId);

    if (!member) {
      throw new Error("ユーザーは認証されていません。");
    }

    let _conversationId = args.conversationId;


    if (!args.conversationId && !args.channelId && args.parentMessageId) {
      const parentMessage = await ctx.db.get(args.parentMessageId);

      if (!parentMessage) {
        throw new Error("親メッセージが見つかりません");
      }

      _conversationId = parentMessage.conversationId;
    }

    const messageId = await ctx.db.insert("messages", {
      memberId: member._id,
      body: args.body,
      image: args.image,
      audio: args.audio,
      video: args.video,
      channelId: args.channelId,
      conversationId: _conversationId,
      workspaceId: args.workspaceId,
      parentMessageId: args.parentMessageId,
    });

    return messageId;
  },
});

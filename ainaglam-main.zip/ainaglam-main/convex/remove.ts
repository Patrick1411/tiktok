import { v } from "convex/values";
import { Id } from "./_generated/dataModel";
import { auth } from "./auth";
import { mutation } from "./_generated/server";


export const deleteById = mutation({
    args: {},
    handler: async (ctx, args) => {
        const userId = await auth.getUserId(ctx);

        if (userId === null) {
            return null;
        }

        const user = await ctx.db.get(userId);

        if (!user) {
            return null;
        }
        return await ctx.storage.delete(user.image as Id<"_storage">);
    },
});
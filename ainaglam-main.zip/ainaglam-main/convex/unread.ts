import { v } from "convex/values";
import { mutation, query, QueryCtx } from "./_generated/server";
import { auth } from "./auth";
import { Id } from "./_generated/dataModel";

const getMember = async (
    ctx: QueryCtx,
    workspaceId: Id<"workspaces">,
    userId: Id<"users">,
) => {
    return ctx.db
        .query("members")
        .withIndex("by_workspace_id_user_id", (q) =>
            q.eq("workspaceId", workspaceId).eq("userId", userId),
        )
        .unique();
};

export const updateUnreadMessage = mutation({
    args: {
        workspaceId: v.id("workspaces"),
        conversationId: v.optional(v.id("conversations")),
        channelId: v.optional(v.id("channels")),
    },
    handler: async (ctx, args) => {

        const userId = await auth.getUserId(ctx);

        if (!userId) {
            return null;
        }

        const member = await getMember(ctx, args.workspaceId, userId);

        if (!member) {
            throw new Error("ユーザーは認証されていません。");
        }

        const now = Date.now();

        if (args.conversationId) {
            const existing = await ctx.db
                .query("readedtime")
                .withIndex("by_user_id_workspace_id_conversation_id", (q) =>
                    q
                        .eq("userId", userId)
                        .eq("workspaceId", args.workspaceId)
                        .eq("conversationId", args.conversationId)
                )
                .first();

            if (existing) {
                await ctx.db.patch(existing._id, { updatedAt: now });
            } else {
                await ctx.db.insert("readedtime", {
                    userId: userId,
                    workspaceId: args.workspaceId,
                    conversationId: args.conversationId,
                    updatedAt: now
                });
            }
        }

        if (args.channelId) {
            const existing = await ctx.db
                .query("readedtime")
                .withIndex("by_user_id_workspace_id_channel_id", (q) =>
                    q
                        .eq("userId", userId)
                        .eq("workspaceId", args.workspaceId)
                        .eq("channelId", args.channelId)
                )
                .first();

            if (existing) {
                await ctx.db.patch(existing._id, { updatedAt: now });
            } else {
                await ctx.db.insert("readedtime", {
                    userId: userId,
                    workspaceId: args.workspaceId,
                    channelId: args.channelId,
                    updatedAt: now
                });
            }
        }
        return now;
    },
});


export const getUnreadMessages = query({
    args: {
      workspaceId: v.id("workspaces"),
    },
    handler: async (ctx, args) => {
      const { workspaceId } = args;
      const userId = await auth.getUserId(ctx);
  
      if (!userId) {
        return null;
      }
  
      const member = await getMember(ctx, workspaceId, userId);
  
      if (!member) {
        throw new Error("ユーザーは認証されていません。");
      }
  
      const readedRecords = await ctx.db
        .query("readedtime")
        .withIndex("by_user_id_workspace_id", (q) =>
          q
            .eq("userId", userId)
            .eq("workspaceId", workspaceId)
        )
        .collect();
  
      const lastReadTime = {
        channels: new Map(),
        conversations: new Map(),
      };
  
      readedRecords.forEach((record) => {
        if (record.channelId) {
          lastReadTime.channels.set(record.channelId, record.updatedAt);
        }
        if (record.conversationId) {
          lastReadTime.conversations.set(record.conversationId, record.updatedAt);
        }
      });
  
      const channels = await ctx.db
        .query("channels")
        .filter((q) => q.eq(q.field("workspaceId"), workspaceId))
        .collect();
  
      const conversations = await ctx.db
        .query("conversations")
        .filter((q) => q.eq(q.field("workspaceId"), workspaceId))
        .collect();
  
      const unreadCounts = await Promise.all([
        ...channels.map(async (channel) => {
          const lastRead = lastReadTime.channels.get(channel._id) || 0;
          const messages = await ctx.db
            .query("messages")
            .withIndex("by_channel_id", (q) => q.eq("channelId", channel._id))
            .filter((q) => q.gt(q.field("_creationTime"), lastRead))
            .collect();
          return { type: "channel", id: channel._id, count: messages.length };
        }),
        ...conversations.map(async (conversation) => {
          const lastRead = lastReadTime.conversations.get(conversation._id) || 0;
          const messages = await ctx.db
            .query("messages")
            .withIndex("by_conversation_id", (q) => q.eq("conversationId", conversation._id))
            .filter((q) => q.gt(q.field("_creationTime"), lastRead))
            .collect();
          return { type: "conversation", id: conversation._id, count: messages.length };
        }),
      ]);
  
      const totalUnreadCount = unreadCounts.reduce((sum, item) => sum + item.count, 0);
  
      return {
        unreadCounts,
        totalUnreadCount,
      };
    },
  });


import { v } from "convex/values";
import { action } from "./_generated/server";

// Define the OGP data type
export type OgpData = {
  url: string;
  title: string | null;
  description: string | null;
  image: string | null;
  siteName: string | null;
};



// Action to fetch OGP data
export const fetchOgpData = action({
  args: { url: v.string() },
  handler: async (ctx, { url }) => {
    try {
      const response = await fetch(url);
      const html = await response.text();
      
      const getMetaContent = (name: string) => {
        const match = html.match(new RegExp(`<meta\\s+(?:property|name)=["']${name}["']\\s+content=["']([^"']+)["']`, 'i'));
        return match ? match[1] : null;
      };

      const ogpData: OgpData = {
        url,
        title: getMetaContent('og:title') || getMetaContent('title'),
        description: getMetaContent('og:description') || getMetaContent('description'),
        image: getMetaContent('og:image'),
        siteName: getMetaContent('og:site_name'),
      };

      // Here you would typically store the fetched OGP data in your Convex database
      // For this example, we'll just return the data
      return ogpData;
    } catch (error) {
      console.error(`Error fetching OGP data for ${url}:`, error);
      return null;
    }
  },
});


